






Sc <- function(Ya,R, pi0a,bet, Za, dist='gaussian', link='identity', 
               bet.PI, X.PINoy,  dist.PI, link.PI, ids=ids.PI, it=100, seedS=65645, fX.PI ) {  
 
  id.sam   <-ids[R==1]
  
  dataS     <- data.frame(X.PINoy,  Ya) 
  
  X.PI     <- cbind(model.matrix(fX.PI , data= dataS))
  X.PI2    <- cbind(X.PI)  
  X.PI2s   <- cbind(X.PI2[R==1, ])
  X.PIs    <- cbind(X.PI[R==1, ])
  
  X.PI.TRUENoy  <- cbind(X.PI.TRUENoy )
  X.PIs.TRUENoy    <- cbind(X.PI.TRUENoy [R==1, ])
  X.PINoy  <- cbind(X.PINoy )
  X.PIsNoy    <- cbind(X.PINoy [R==1, ])
  
  ### This change when Y included and when not. 
  
  
  X <- X.PIs
  Z <- cbind(Za[R==1, ])
  Y <- Ya[R==1 ]    
  pi0 <- pi0a[R==1]
  W     <- diag(1/pi0)
  w     <- 1/pi0	
  OneV  <- rep(1, length(pi0))
  n     <- length(w)
  
  wth   <- 10
  
  
  if( dist=='gaussian'){  
    if(link=='identity'){   
      
      MU  <- as.vector(Z%*%bet ) 
      D   <- Z
      I   <-  matrix(0, ncol(Z) , ncol(Z)) 
      
      Vi      <-  var(Y-MU)
      n       <-  length(MU)
      IdY2    <-   rep(1:n, it) 
      MU2     <-  rep(MU,it)
      
      SD      <-  sd(Y)
      #Y2      <-  rnorm(it*n,  MU2 , sd = SD)
      Y2     <-  sort(rep(seq(min(MU-wth*SD), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dnorm(  Y2, MU2, SD  )
      
      w2      <-  rep(w, it)
      D2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
       
      
      Spi2       <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI ) 
      
      pi02aux  <-  rep(pi0, it )
      pi02      <-  Spi2$MU 
      D2pi       <- Spi2$D 
      
      
      #Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      #pi02     <-  Spi2$MU
      #D2pi      <- Spi2$D 
      #E_Uc  <- data.matrix(aggregate((Y2-MU2)*pi02~IdY2, FUN='mean' ))
      
     # E_Uc  <- data.matrix(aggregate((Y2 -MU2)*pi02*paux ~IdY2, FUN='sum' ))
      aux00  <-  (Y2 -MU2)*pi02*paux
      aux11  <-   rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
       
      
      #E_pic <- data.matrix(aggregate( pi02*paux ~IdY2, FUN='sum' ))
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
     
      Y_MU.est <-  as.vector(E_Uc[,2])/(E_pic[,2]) 
      
      I.est  <- t(D*0* as.vector( Y-MU - Y_MU.est )  )%*%D
      
      ##
      
    }
    
    if(link=='log'){         
      MU <- as.vector(exp(Z%*%bet) )
      D  <- MU*Z  
      Vi      <-  var(Y-MU)
      n       <-  length(MU)
      IdY2    <-   rep(1:n, it) 
      MU2     <-  rep(MU,it)
      SD      <-  sd(Y)
      #Y2      <-  rnorm(it*n,  MU2 , sd = SD)
      
      Y2     <-  sort(rep(seq(min(MU-wth*SD), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dnorm(  Y2, MU2, SD  )
      
      
      
      w2      <-  rep(w, it)
      D2      <-  MU2*matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      Spi2       <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      pi02aux  <-  rep(pi0, it )
      pi02      <-  Spi2$MU 
      
      D2pi       <- Spi2$D 
      # E_Uc  <- data.matrix(aggregate((Y2 -MU2)*pi02*paux ~IdY2, FUN='sum' ))
      aux00  <-  (Y2 -MU2)*pi02*paux
      aux11  <-   rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
      #E_pic <- data.matrix(aggregate( pi02*paux ~IdY2, FUN='sum' ))
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      #  Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      #  pi02     <-  Spi2$MU
      #  D2pi      <- Spi2$D 
      #  E_Uc  <- data.matrix(aggregate((Y2-MU2)*pi02~IdY2, FUN='mean' ))
      #  E_pic <- data.matrix(aggregate( pi02~IdY2, FUN='mean' ))
      
      
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      
      I.est   <- t(Z*  MU * as.vector( Y-MU - Y_MU.est ))%*%Z
      
      
      
    }
    
    if(link=='inverse'){      
      MU <- as.vector(1/(Z%*%bet))  
      D  <- -MU^2*Z
      I  <- 2*t(Z)%*% (Z*MU^3) 
      
      Vi      <-  var(Y-MU)
      n       <-  length(MU)
      IdY2    <-   rep(1:n, it) 
      MU2     <-  rep(MU,it)
      SD      <-  sd(Y)
      #Y2      <-  rnorm(it*n,  MU2 , sd = SD)
      
      Y2     <-  sort(rep(seq(min(MU-wth*SD), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dnorm(  Y2, MU2, SD  )
      
      w2      <-  rep(w, it)
      D2      <-  -MU2^2*matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      Spi2       <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      pi02aux  <-  rep(pi0, it )
      pi02      <-  Spi2$MU 
      D2pi       <- Spi2$D 
      #E_Uc  <- data.matrix(aggregate((Y2 -MU2)*pi02*paux ~IdY2, FUN='sum' ))
      # E_Uc  <- data.matrix(aggregate((Y2 -MU2)*pi02*paux ~IdY2, FUN='sum' ))
      aux00  <-  (Y2 -MU2)*pi02*paux
      aux11  <-   rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
      #E_pic <- data.matrix(aggregate( pi02*paux ~IdY2, FUN='sum' ))
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
      #Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      #pi02      <-  Spi2$MU
      #D2pi      <- Spi2$D 
      #E_Uc      <- data.matrix(aggregate((Y2-MU2)*pi02~IdY2, FUN='mean' ))
      #E_pic     <- data.matrix(aggregate( pi02~IdY2, FUN='mean' ))
      
      Y_MU.est  <-  (E_Uc[,2])/(E_pic[,2]) 
      
      
      I.est  <-  2*t(Z* (   MU^3 )* as.vector( Y-MU - Y_MU.est ))%*%Z
      
      
    }
    
    
   # D_Uc  <-  data.matrix(aggregate(D2*pi02*paux~IdY2, FUN='sum' )  )
     aux00  <-   D2*pi02*paux
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc   <-  cbind( as.numeric(rownames(aux11)),   (aux11))
      
    D.est <-  data.matrix((D_Uc[,-1]/(E_pic[,2])) )
    
    ##
    #D.U.pi  <-  data.matrix(aggregate(D2*pi02*((Y2-MU2))*paux~IdY2, FUN='sum' )  )
    aux00  <-   D2*pi02*((Y2-MU2))*paux
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
        
    #D.U2.pi  <-  data.matrix(aggregate(D2*pi02*((Y2-MU2)^2)*paux~IdY2, FUN='sum' )  )
    aux00  <-   D2*pi02*((Y2-MU2)^2)*paux
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U2.pi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
     
    
    Dev.fy <- t(D.U2.pi[,-1]/(E_pic[,2]) - (D.U.pi[,-1]*E_Uc[,-1]/(E_pic[,2]^2) )  ) %*%D
    
     
    ##
    ### Do not need to expand because each set of Ys have the same weight
    
    
    
    #Y_MDpi     <-  data.matrix(aggregate( paux*(Y2-MU2)*(D2pi   )  ~IdY2, FUN='sum' )   ) 
    aux00  <-   paux*(Y2-MU2)*(D2pi    )
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
    
    Y_MDpi.pi  <- (	cbind(Y_MDpi[,-1]) /as.vector(E_pic[,2]))
    
 
    
    #E_Dpi     <-  data.matrix(aggregate(  paux*D2pi  ~IdY2, FUN='sum' )  ) 
    aux00  <-   paux*D2pi
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
    
    E_Dpi.pi  <- (E_Dpi[,-1] /as.vector(E_pic[,2]^2))
    
    
    
    dScbet  <- -t(D)%*%(D ) +t(D)%*%(D.est )  +I.est -Dev.fy
    
    #Uc22       <-   data.matrix(aggregate( ( paux*(Y2- MU2)^2*pi02    ) ~IdY2, FUN='sum' ) ) 
    aux00  <-   paux*(Y2- MU2)^2*pi02 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Uc22    <- data.frame( rownames(aux11),   (aux11))
    
    
    
    Uc22est    <-   as.vector(( Uc22[,-1] /(E_pic[,2])))
    
    dScbetEst  <-  - t(D*Uc22est )%*%D
    
    
    
    
    dScpi    <- -t(D)%*%(Y_MDpi.pi ) + t(D)%*% (as.vector(E_Uc[,2])*E_Dpi.pi ) 
    
     
    
    Uwi   <- D*(as.vector(Y-MU)*w) 
    Sw    <- colSums(Uwi) 
    
    Uci   <- D*(as.vector(Y-MU) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
  }
  
  
  if( dist=='binomial'){  
    if(link=='identity' || link=='logit' ){ MU <-  as.vector(1/(1+exp(-Z%*%bet) ) )
    D  <- MU*(1-MU)*Z
    I  <- t(Z)%*% ( ((1-2*MU)*(1-MU)*MU)*Z)	
    Vi      <-   (1-MU)*MU
    n       <-  length(MU)
    IdY2    <-   rep(1:n, 2) 
    
    
    MU2    <-  rep(MU,2) 
    Y2     <-  sort(rep(0:1, n))
    D2     <-  MU2*(1-MU2)*matrix(rep(t(Z),2), 2*n,ncol(Z), byrow=TRUE)  
    
    it0 <-2
    
    aa0     <- rep(t(X.PIsNoy),it0)
    nAA     <- ncol(X.PIsNoy)
    AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
    XbigNoy.PI  <- cbind(AA0)
    
    dataBig   <- data.frame(XbigNoy.PI,  Y2)
    colnames(dataBig)   <- colnames(dataS)  
    Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
    
    
    
    Spi2    <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
    pi02aux   <-   rep(pi0, 2 )
    pi02      <-  Spi2$MU 
    
    D2pi     <- Spi2$D 
    Uic      <- (Y2-MU2)/(MU2*(1-MU2))
    pY       <- MU*Y + (1-MU)*(1-Y)
    pY2      <- MU2*Y2 + (1-MU2)*(1-Y2)
    #E_Uc     <- data.matrix(aggregate(Uic*pi02*pY2~IdY2, FUN='sum' ))
    aux00  <-   Uic*pi02*pY2
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Uc    <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
    #E_pic    <-  data.matrix(aggregate( pi02*pY2~IdY2, FUN='sum' ))
    aux00  <-   pi02*pY2
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_pic     <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
     
    
    
    Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
    
    w2      <-  rep(w, 2)
    
    I.est   <- t(Z*  (MU)*(1-2*MU)*(1-MU) * (  (Y-MU)/(MU *(1-MU ))  - Y_MU.est ))%*%Z
    
    }
    
    if(link=='log'){                        
      MU <-   as.vector(exp( Z%*%bet ))
      D  <- MU*Z	
      I  <- t(Z)%*% (MU*Z) 
      
      Vi      <-   (1-MU)*MU
      n       <-  length(MU)
      IdY2    <-   rep(1:n, 2) 
      MU2     <-  rep(MU,2) 
      Y2      <-  sort(rep(0:1, n))
      w2      <-  rep(w, 2)
      D2      <-  MU2* matrix(rep(t(Z),2), 2*n,ncol(Z), byrow=TRUE)  
      
      it0 <-2
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
     
      
      Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      pi02aux   <-   rep(pi0, 2 )
     
      
      pi02      <-  Spi2$MU 
      
      
      
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2-MU2)/(MU2*(1-MU2))
      pY       <- MU*Y + (1-MU)*(1-Y)
      pY2      <- MU2*Y2 + (1-MU2)*(1-Y2)
 
      #E_Uc     <- data.matrix(aggregate(Uic*pi02*pY2~IdY2, FUN='sum' ))
      aux00  <-   Uic*pi02*pY2
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc    <-cbind( as.numeric(rownames(aux11)),  (aux11))
      
      
      
      #E_pic    <-  data.matrix(aggregate( pi02*pY2~IdY2, FUN='sum' ))
      aux00  <-   pi02*pY2
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic     <- cbind( as.numeric(rownames(aux11)),  (aux11))
      
      
      
      
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      w2      <-  rep(w, 2)
      
      
      I.est   <- t(Z*  (MU) * (  (Y-MU)/(MU *(1-MU ))  - Y_MU.est ))%*%Z
    }
    
    if(link=='probit'){   Nu <-  as.vector(Z%*%bet)                   
    MU <-  pnorm(Nu) 
    D  <-  dnorm(Nu)*Z		
    
    I  <-  t(Z)%*% (   -Nu*dnorm(Nu)  *Z)
    Vi      <-   (1-MU)*MU
    n       <-  length(MU)
    IdY2    <-   rep(1:n, 2) 
    MU2     <-  rep(MU,2) 
    Y2     <-  sort(rep(0:1, n)) 
    
    Z2      <-  matrix(rep(t(Z),2), 2*n,ncol(Z), byrow=TRUE)  
    Nu2     <-  as.vector(Z2%*%bet)                   
    MU2     <-  pnorm(Nu2) 
    
    D2      <-  dnorm(Nu2)*Z2		
    
    it0 <-2
    
    aa0     <- rep(t(X.PIsNoy),it0)
    nAA     <- ncol(X.PIsNoy)
    AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
    XbigNoy.PI  <- cbind(AA0)
    
    dataBig   <- data.frame(XbigNoy.PI,  Y2)
    colnames(dataBig)   <- colnames(dataS)  
    Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
    
    
    
    
    
    Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
    pi02aux   <-   rep(pi0, 2 )
    pi02      <-  Spi2$MU 
    
    D2pi      <- Spi2$D 
    
    Uic   <- (Y2-MU2)/(MU2*(1-MU2))
    pY       <- MU*Y + (1-MU)*(1-Y)
    pY2      <- MU2*Y2 + (1-MU2)*(1-Y2)
    #E_Uc     <- data.matrix(aggregate(Uic*pi02*pY2~IdY2, FUN='sum' ))
    aux00  <-   Uic*pi02*pY2
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Uc    <- cbind( as.numeric(rownames(aux11)),  (aux11))
    
    
    
    #E_pic    <-  data.matrix(aggregate( pi02*pY2~IdY2, FUN='sum' ))
    aux00  <-   pi02*pY2
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_pic     <- cbind( as.numeric(rownames(aux11)),  (aux11))
    
    Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
    w2      <-  rep(w, 2)
    
    I.est   <- - t(Z*    Nu*dnorm(Nu)* (  (Y-MU)/(MU *(1-MU ))  - Y_MU.est ))%*%Z
    
    
    }
    
    

    
     aux00  <-   pY2*D2*pi02*(((Y2-MU2)/(MU2*(1-MU2))))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
  
    
    Dev.fy <-  - t(D.U.pi[,-1] /(E_pic[,2]^2)   ) %*%D.U.pi[,-1]
    
    
      aux00  <-   (pY2*(Y2-MU2)/(MU2*(1-MU2)))*(D2pi   ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
    
    
    Y_MDpi.pi  <- (	Y_MDpi[,-1] /(E_pic[,2])) 
    
    #E_Dpi     <-  data.matrix(aggregate(  pY2*D2pi  ~IdY2, FUN='sum' )  ) 
    aux00  <-   pY2*D2pi
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    E_Dpi.pi  <- (E_Dpi[,-1] /(E_pic[,2] )^2)
    
     
    
  
    
    dScbet  <-   - t(D)%*%(D*(Y-MU)^2 /((1-MU)^2*MU^2 ))  + I.est - Dev.fy
    
  
 
    
    
     #Uc22       <-   data.matrix(aggregate( ( pY2*(Y2- MU2)^2*pi02    ) ~IdY2, FUN='sum' ) ) 
     aux00  <-  ( pY2*(Y2- MU2)^2*pi02    )
     aux11  <-  rowsum( aux00 , as.factor(IdY2))
     Uc22   <- cbind( as.numeric(rownames(aux11)),   (aux11))
     
     
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
   
    
 
     
  
    dScbetEst  <-  - t(D*Uc22est/(MU^2*(1-MU)^2))%*%D     
    
    
 
     
    
    dScpi   <- -(  t(D)%*%(Y_MDpi.pi ) - t(D)%*% (	as.vector(E_Uc[,2])*E_Dpi.pi ) )
    
    
    Vi     <-  (1 -MU)*(MU )
    Uwi    <-  D*(as.vector(Y-MU)/Vi)  
    
    Sw     <-  colSums(Uwi*w) 
    
    
     
    Uci   <- D*(as.vector((Y-MU)/Vi) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
    
  }
  
  if( dist=='poisson'){  
    itaux      <-  mean(Ya) + max(Ya)
    it         <- round(itaux )+1
    
    
    if(link=='identity' || link=='log' ){   
      
      
      
      MU <-  as.vector(exp(Z%*%bet)  )
      D  <-  MU*Z		
      I  <-  t(Z) %*% (Z* MU^2)
      Vi      <-  MU
       n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      #Y2      <-  rpois(it*n,  MU2  )
      
      
      Y2      <-  sort(rep(0:(it-1), n)) 
      paux   <-    dpois(  Y2, MU2   )
      
      
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-  MU2*Z2		
      
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2-MU2)/(MU2 )
      #E_Uc  <- data.matrix(aggregate(Uic*pi02*paux~IdY2, FUN='sum' ))
      #E_pic <- data.matrix(aggregate( pi02*paux~IdY2, FUN='sum' ))
      
      
      aux00  <-  Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
      
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <- t(Z*      MU* (  (Y-MU)/(MU )  - Y_MU.est ))%*%Z
      
    }
    
    if(link=='sqrt'){     
      MU <-   as.vector(( Z%*%bet )^2)
       
      D  <- 2*sqrt(MU)*Z	
      I  <- t(Z)%*% ( Z	/sqrt(MU)) 
      Vi      <-  MU
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      #Y2      <-  rpois(it*n,  MU2  )
      Y2      <-   sort(rep(0:(it-1), n)) 
      paux   <-    dpois(  Y2, MU2   )
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-  2*sqrt(MU2)*Z2		
      
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2-MU2)/(MU2 )
      #E_Uc  <- data.matrix(aggregate(Uic*pi02*paux ~IdY2, FUN='sum' ))
      #E_pic <- data.matrix(aggregate( pi02*paux~IdY2, FUN='sum' ))
      
      aux00  <-  Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <- 2*t(Z*   (  (Y-MU)/(MU )  - Y_MU.est ))%*%Z
      
      
    }
    
    #D_Uc  <-  data.matrix(aggregate(D2*pi02*paux~IdY2, FUN='sum' )  )
    aux00  <-  D2*pi02*paux
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    D.est <-  data.matrix((D_Uc[,-1]/(E_pic[,2])) )
    
    #D_Uc2  <-  data.matrix(aggregate(paux*D2*pi02*Y2/(MU^2)~IdY2, FUN='sum' )  )
    aux00  <-  paux*D2*pi02*Y2/(MU^2)
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc2    <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    D.est2 <-  data.matrix((D_Uc2[,-1]/(E_pic[,2])) )
    
    #D.U.pi  <-  data.matrix(aggregate(D2*paux*pi02*(((Y2-MU2)/(MU2 )))~IdY2, FUN='sum' )  )
    #D.U2.pi  <-  data.matrix(aggregate(D2*paux*pi02*((((Y2-MU2)/(MU2 ))^2))~IdY2, FUN='sum' )  )
    
    aux00  <-  D2*paux*pi02*(((Y2-MU2)/(MU2 )))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    aux00  <-  D2*paux*pi02*((((Y2-MU2)/(MU2 ))^2))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U2.pi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
    
    
    Dev.fy <- t(D.U2.pi[,-1]/(E_pic[,2]) - (D.U.pi[,-1]*E_Uc[,-1]/(E_pic[,2]^2) )  ) %*%D
    
    
    ##
    
    ### Do not need to expand because each set of Ys have the same weight
    #Y_MDpi     <-  data.matrix(aggregate( paux*(Y2-MU2)*(D2pi/MU2   )  ~IdY2, FUN='sum' )   ) 
    aux00  <-  paux*(Y2-MU2)*(D2pi/MU2   )
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi    <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
    Y_MDpi.pi  <- (	Y_MDpi /(E_pic[,2]))[,-1]
    
    #E_Dpi     <-  data.matrix(aggregate(  D2pi*paux  ~IdY2, FUN='sum' )  ) 
    aux00  <-  D2pi*paux 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi     <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
    E_Dpi.pi  <- (E_Dpi /(E_pic[,2]^2))[,-1]
    
    
    
    dScbet  <- -t(D)%*%( D*Y/(MU^2) ) +t(D)%*%(D.est2 )  +I.est -Dev.fy
    
    #Uc22       <-   data.matrix(aggregate( ( paux*(Y2- MU2)^2*pi02    ) ~IdY2, FUN='sum' ) ) 
    aux00  <-  ( paux*(Y2- MU2)^2*pi02    ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Uc22      <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
  
    
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
    
    dScbetEst  <-  - t(D*Uc22est/MU^2 )%*%D
    
    
    
    
    
    dScpi   <- -t(D)%*%(Y_MDpi.pi ) + t(D)%*% (E_Uc[,2]*E_Dpi.pi ) 
    
    Vi     <-   (MU )
    Uwi    <-  D*(as.vector(Y-MU)/Vi)  
    
    Sw     <-  colSums(Uwi*w) 
    
    
    
    Uci   <- D*(as.vector((Y-MU)/Vi) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
  }        
  
  if( dist=='Exponential'){  
    if(link=='identity' || link=='inverse'){ 
      MU <-   as.vector(-1/( Z%*%bet )) 
      D  <-   MU^2 *Z		
      I  <-   t(Z)%*% ((2*MU^3)*Z )
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      # Y2     <-  rexp(it*n, 1/ MU2  )
      SD      <- max(  MU^2)
      
      Y2     <-  sort(rep(seq(0, max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dexp(  Y2,1/ MU2  )
      
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   (MU2^2)*Z2		
      
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2 -MU2)/(MU2^2 )
      #E_Uc  <- data.matrix(aggregate(Uic*pi02*paux~IdY2, FUN='sum' ))
      #E_pic <- data.matrix(aggregate( pi02*paux~IdY2, FUN='sum' ))
      
       aux00  <-   Uic*pi02*paux
        aux11  <-  rowsum( aux00 , as.factor(IdY2))
        E_Uc <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-   pi02*paux
        aux11  <-  rowsum( aux00 , as.factor(IdY2))
        E_pic<- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <-   2*t(Z* MU^3*  (  (Y-MU)/(MU^2 )  - Y_MU.est ))%*%Z
      
    }
    
    if(link=='log'){       
      MU <-  as.vector( exp( Z%*%bet ))
      D  <-   MU *Z	
      I  <-   t(Z)%*% ( Z*MU ) 
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      #Y2      <-  rexp(it*n,  1/MU2  )
      SD      <- max(  MU^2)
      
      Y2     <-  sort(rep(seq(0, max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dexp(  Y2,1/ MU2  )
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   (MU2)*Z2		
      
      
      it0 <-it
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2-MU2 )/(MU2^2 )
      #E_Uc  <- data.matrix(aggregate(paux*Uic*pi02~IdY2, FUN='sum' ))
      E#_pic <- data.matrix(aggregate( paux*pi02~IdY2, FUN='sum' ))
      
      aux00  <-   Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-   pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic<- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <-  t(Z* MU*  (  (Y-MU )/(MU^2 )  - Y_MU.est ))%*%Z 
    }
    
    # D_Uc  <-  data.matrix(aggregate(paux*D2*pi02~IdY2, FUN='sum' )  )
    aux00  <-    paux*D2*pi02
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
 
    D.est <-  data.matrix((D_Uc[,-1]/(E_pic[,2])) )
    #D_Uc2  <-  data.matrix(aggregate(paux*D2*pi02*(Y2-MU2)/(MU2^3)~IdY2, FUN='sum')  )
    aux00  <-    paux*D2*pi02*(Y2-MU2)/(MU2^3)
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc2<- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    D.est2 <-  data.matrix((D_Uc2[,-1]/(E_pic[,2])) )
    ##
    
    #D.U.pi  <-  data.matrix(aggregate(paux*D2*pi02*(((Y2-MU2)/(MU2^2 )))~IdY2, FUN='sum' )  )
    aux00  <-   paux*D2*pi02*(((Y2-MU2)/(MU2^2 )))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi<- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    #D.U2.pi  <-  data.matrix(aggregate(paux*D2*pi02*((((Y2-MU2)/(MU2^2 ))^2))~IdY2, FUN='sum' )  )
    aux00  <-   paux*D2*pi02*((((Y2-MU2)/(MU2^2 ))^2))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U2.pi <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    Dev.fy <- t(D.U2.pi[,-1]/(E_pic[,2]) - (D.U.pi[,-1]*E_Uc[,-1]/(E_pic[,2]^2) )  ) %*%D
    
    ### Do not need to expand because each set of Ys have the same weight
    #Y_MDpi     <-  data.matrix(aggregate( (paux*(Y2-MU2))*(D2pi/(MU2^2)   )  ~IdY2, FUN='sum' )   ) 
    aux00  <-   (paux*(Y2-MU2))*(D2pi/(MU2^2)   ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    Y_MDpi.pi  <- (	Y_MDpi /(E_pic[,2]))[,-1]
    
    #E_Dpi     <-  data.matrix(aggregate(  paux*D2pi  ~IdY2, FUN='sum' )  ) 
    aux00  <-   paux*D2pi 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    E_Dpi.pi  <- (E_Dpi /(E_pic[,2]^2))[,-1]
    
    
    
    dScbet  <- -t(D)%*%( D*(Y-MU)/(MU^3) ) +t(D)%*%(D.est2 )  +I.est -Dev.fy
   
    
    
    
    #Uc22       <-   data.matrix(aggregate( (  paux*(Y2- MU2)^2*pi02    ) ~IdY2, FUN='sum' ) ) 
    aux00  <-    (  paux*(Y2- MU2)^2*pi02    )
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Uc22  <-  cbind( as.numeric(rownames(aux11)),   (aux11))
    
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
    
    dScbetEst  <-  - t(D*Uc22est/MU^4 )%*%D
    
    
    dScpi   <- -t(D)%*%(Y_MDpi.pi ) + t(D)%*% (E_Uc[,2]*E_Dpi.pi ) 
    
    Vi     <-  (MU^2 )
    Uwi    <-  D*(as.vector(Y-MU)/Vi)  
    
    Sw     <-  colSums(Uwi*w) 
    
    Uci   <- D*(as.vector((Y-MU)/Vi) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
  } 
  
  if( dist=='Gamma'){  
    if(link=='identity' || link=='inverse'){ 
      MU <- as.vector(-1/( Z%*%bet )) 
      D  <- MU^2 *Z	
      I  <- t(Z)%*% ((2*MU^3)*Z) 	
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      # Y2     <-  rexp(it*n, 1/ MU2  )
      SD      <- sd(Y)
      Y2     <-  sort(rep(seq(10^(-10), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dgamma(  Y2,shape= 1, scale= MU2  )
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   (MU2^2)*Z2		
      
      
      it0 <-it
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2 -MU2)/(MU2^2 )
     # E_Uc  <- data.matrix(aggregate(paux*Uic*pi02~IdY2, FUN='sum'  ))
      #E_pic <- data.matrix(aggregate( paux*pi02~IdY2, FUN='sum'  ))
      aux00  <-   Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-   pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic<- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <-   2*t(Z* MU^3*  (  (Y-MU)/(MU^2 )  - Y_MU.est ))%*%Z
      
      
      
      
    }
    
    if(link=='inverse2'){                   
      MU <-  as.vector(1/( Z%*%bet ))
      D  <- -MU^2 *Z	 	
      I  <- -t(Z)%*% ((-2*MU^3)*Z) 	
      Iw  <- -t(Z)%*% ((-2*MU^3)*Z*w) 
      
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      # Y2     <-  rexp(it*n, 1/ MU2  )
      SD      <- sd(Y)
      Y2     <-  sort(rep(seq(10^(-10), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dgamma(  Y2,shape= 1, scale=  MU2  ) #dgamma(  Y2,shape= MU2^2/SD^2, scale= SD^2/MU2  )
      
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   -(MU2^2)*Z2		
      
      
      
      it0 <-it
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2 -MU2)/(MU2^2 )
      # E_Uc  <- data.matrix(aggregate(paux*Uic*pi02~IdY2, FUN='sum'  ))
      #E_pic <- data.matrix(aggregate( paux*pi02~IdY2, FUN='sum'  ))
      aux00  <-   Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-   pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic<- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <- 2*t(Z* MU^3*  (  (Y-MU)/(MU^2 )  - Y_MU.est ))%*%Z
      
      
      
      
    }
    
    if(link=='log'){      
      MU <- as.vector(exp(Z%*%bet)  )
      D  <- MU*Z		
      I  <- t(Z)%*% ( MU*Z ) 
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      # Y2     <-  rexp(it*n, 1/ MU2  )
      SD      <- sd(Y)
      Y2     <-  sort(rep(seq(10^(-10), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dgamma(  Y2,shape= 1, scale= MU2  )
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   (MU2)*Z2		
      
      
     
      it0 <-it
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      Spi2      <- SWpiaux(   bet.PI, Xbig.PI,  dist.PI, link.PI )
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2 -MU2)/(MU2^2 )
      # E_Uc  <- data.matrix(aggregate(paux*Uic*pi02~IdY2, FUN='sum'  ))
      #E_pic <- data.matrix(aggregate( paux*pi02~IdY2, FUN='sum'  ))
      aux00  <-   Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-   pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic<- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <-  t(Z* MU*  (  (Y -MU)/(MU^2 )  - Y_MU.est ))%*%Z
      
      
      
      
    }
    
    
    #D_Uc  <-  data.matrix(aggregate(paux*D2*pi02~IdY2, FUN='sum' )  )
 
    aux00  <- paux*D2*pi02
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    D.est <-  data.matrix((D_Uc[,-1]/(E_pic[,2])) )
    #D_Uc2  <-  data.matrix(aggregate(paux*D2*pi02*(Y2-MU2)/(MU2^3)~IdY2, FUN='sum')  )
    aux00  <- paux*D2*pi02*(Y2-MU2)/(MU2^3)
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc2 <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    D.est2 <-  data.matrix((D_Uc2[,-1]/(E_pic[,2])) )
    ##
    
    #D.U.pi  <-  data.matrix(aggregate(paux*D2*pi02*(((Y2-MU2)/(MU2^2 )))~IdY2, FUN='sum' )  )
    aux00  <- paux*D2*pi02*(((Y2-MU2)/(MU2^2 )))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    #D.U2.pi  <-  data.matrix(aggregate(paux*D2*pi02*((((Y2-MU2)/(MU2^2 ))^2))~IdY2, FUN='sum' )  )
    aux00  <- paux*D2*pi02*((((Y2-MU2)/(MU2^2 ))^2))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U2.pi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    Dev.fy <- t(D.U2.pi[,-1]/(E_pic[,2]) - (D.U.pi[,-1]*E_Uc[,-1]/(E_pic[,2]^2) )  ) %*%D
    
    
    ### Do not need to expand because each set of Ys have the same weight
    #Y_MDpi     <-  data.matrix(aggregate( (paux*(Y2-MU2))*(D2pi/(MU2^2)   )  ~IdY2, FUN='sum' )   ) 
    aux00  <-   (paux*(Y2-MU2))*(D2pi/(MU2^2)   ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    Y_MDpi.pi  <- (	Y_MDpi /(E_pic[,2]))[,-1]
    
    #E_Dpi     <-  data.matrix(aggregate(  paux*D2pi  ~IdY2, FUN='sum' )  ) 
    aux00  <-   paux*D2pi
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    E_Dpi.pi  <- (E_Dpi /(E_pic[,2]^2))[,-1]
    
    
    
    dScbet  <- -t(D)%*%( D*(Y-MU)/(MU^3) ) +t(D)%*%(D.est2 )  +I.est -Dev.fy
    
    
    
    #Uc22       <-   data.matrix(aggregate( (  paux*(Y2- MU2)^2*pi02    ) ~IdY2, FUN='sum' ) ) 
    aux00  <-   (  paux*(Y2- MU2)^2*pi02    ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Uc22    <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
    
    dScbetEst  <-  - t(D*Uc22est/MU^4 )%*%D
    
    
    
    dScpi   <- -t(D)%*%(Y_MDpi.pi ) + t(D)%*% (E_Uc[,2]*E_Dpi.pi ) 
    
    Vi     <-   (MU^2 )
    Uwi    <-  D*(as.vector(Y-MU)/Vi)  
    
    Sw     <-  colSums(Uwi*w) 
    
    
    
    Uci   <- D*(as.vector((Y-MU)/Vi) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
  }   
  
  return(list(MU=MU,Sc.s=Sc.s, Sw=Sw, Uwi=	Uwi, 	 w=	 w  , Uci=Uci,    ids= ids,   
              D,   dScbet=dScbet, dScpi=dScpi, E_Uc=E_Uc, pis=pi0, D.U.pi =D.U.pi, id.sam=id.sam   , dScbetEst= dScbetEst      ))
  
}


















###############
###### FOR CALIBRATION
########






ScCal <- function(Ya,R, pi0a,bet, Za, dist='gaussian', link='identity', 
                  bet.PI, X.PINoy,  distance='chi', ids=ids.PI, it=100, seedS=65645,  X.PI.TRUENoy , pFUN0  ,   fX.PI ){  
  
  
  id.sam   <-ids[R==1]
  
  dataS     <- data.frame(X.PINoy,  Ya) 
  
  X.PI     <- cbind(model.matrix(fX.PI , data= dataS))
  X.PI2    <- cbind(X.PI)  
  X.PI2s   <- cbind(X.PI2[R==1, ])
  X.PIs    <- cbind(X.PI[R==1, ])
   
  X.PI.TRUENoy  <- cbind(X.PI.TRUENoy )
  X.PIs.TRUENoy    <- cbind(X.PI.TRUENoy [R==1, ])
  X.PINoy  <- cbind(X.PINoy )
  X.PIsNoy    <- cbind(X.PINoy [R==1, ])
  
  
  
  ### This change when Y included and when not. 
  
  
  X <- X.PI[R==1, ]
  Z <- Za[R==1, ]
  Y <- Ya[R==1 ]    
  pi0 <- pi0a[R==1]
  W     <- diag(1/pi0)
  w     <- 1/pi0	
  OneV  <- rep(1, length(pi0))
  n     <- length(w)
  
  wth   <- 10
  
  
  if( dist=='gaussian'){  
    if(link=='identity'){   
      
      MU  <- as.vector(Z%*%bet ) 
      D   <- Z
      I   <-  matrix(0, ncol(Z) , ncol(Z)) 
      Vi      <-  var(Y-MU)
      n       <-  length(MU)
      IdY2    <-   rep(1:n, it) 
      MU2     <-  rep(MU,it)
      SD      <-  sd(Y)
      #Y2      <-  rnorm(it*n,  MU2 , sd = SD)
      Y2     <-  sort(rep(seq(min(MU-wth*SD), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dnorm(  Y2, MU2, SD  )
      
      w2      <-  rep(w, it)
      D2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)
      
      
      it0 <-it
      
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      ##############
      ###############
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      D2pi       <- Spi2$D 
      
      aux00  <-  (Y2 -MU2)*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est  <- t(D*0* as.vector( Y-MU - Y_MU.est )  )%*%D
      
    }
    
    if(link=='log'){         
      MU <- as.vector(exp(Z%*%bet) )
      D  <- MU*Z  
      Vi      <-  var(Y-MU)
      n       <-  length(MU)
      IdY2    <-   rep(1:n, it) 
      MU2     <-  rep(MU,it)
      SD      <-  sd(Y)
      Y2     <-  sort(rep(seq(min(MU-wth*SD), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dnorm(  Y2, MU2, SD  )
      
      w2      <-  rep(w, it)
      D2      <-  MU2*matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi       <- Spi2$D 
      aux00  <-  (Y2 -MU2)*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      I.est   <- t(Z*  MU * ( Y-MU - Y_MU.est ))%*%Z
      
      
      
    }
    
    if(link=='inverse'){      
      MU <- as.vector(1/(Z%*%bet))  
      D  <- -MU^2*Z
      I  <- 2*t(Z)%*% (Z*MU^3) 
      
      Vi      <-  var(Y-MU)
      n       <-  length(MU)
      IdY2    <-   rep(1:n, it) 
      MU2     <-  rep(MU,it)
      SD      <-  sd(Y)
      #Y2      <-  rnorm(it*n,  MU2 , sd = SD)
      
      Y2     <-  sort(rep(seq(min(MU-wth*SD), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dnorm(  Y2, MU2, SD  )
      
      w2      <-  rep(w, it)
      D2      <-  -MU2^2*matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi       <- Spi2$D 
      
      aux00  <-  (Y2 -MU2)*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est  <-  (E_Uc[,2])/(E_pic[,2])  
      I.est  <-  2*t(Z* (   MU^3 )* ( Y-MU - Y_MU.est ))%*%Z
      
      
    }
    
    aux00  <-  D2*pi02*paux
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    D.est <-  data.matrix((D_Uc[,-1]/(E_pic[,2])) )
    aux00  <-  D2*pi02*((Y2-MU2))*paux
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    aux00  <-  D2*pi02*((Y2-MU2)^2)*paux
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U2.pi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    Dev.fy <- t(D.U2.pi[,-1]/(E_pic[,2]) - (D.U.pi[,-1]*E_Uc[,-1]/(E_pic[,2]^2) )  ) %*%D
    D.est <-  data.matrix((D_Uc[,-1]/(E_pic[,2])) )
    ##
    ### Do not need to expand because each set of Ys have the same weight
    
    aux00  <-   paux*(Y2-MU2)*(D2pi    )
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    Y_MDpi.pi  <- (	Y_MDpi[,-1] /(E_pic[,2]))
    
    aux00  <-   paux*D2pi
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    E_Dpi.pi  <- (E_Dpi /(E_pic[,2]^2))[,-1]
    
    dScbet  <- -t(D)%*%(D ) +t(D)%*%(D.est )  +I.est -Dev.fy
    
    dScpi   <- -t(D)%*%(Y_MDpi.pi ) + t(D)%*% (E_Uc[,2]*E_Dpi.pi ) 
    
    aux00  <-   paux*(Y2- MU2)^2*pi02 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Uc22    <- data.frame( rownames(aux11),   (aux11))
    
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
    
    dScbetEst  <-  - t(D*Uc22est )%*%D
    
    Uwi   <- D*(as.vector(Y-MU)*w) 
    Sw    <- colSums(Uwi) 
    
    Uci   <- D*(as.vector(Y-MU) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
  }
  
  
  if( dist=='binomial'){  
    if(link=='identity' || link=='logit' ){
      MU <-  as.vector(1/(1+exp(-Z%*%bet) ) )
      D  <- MU*(1-MU)*Z
      I  <- t(Z)%*% ( ((1-2*MU)*(1-MU)*MU)*Z)	
      Vi      <-   (1-MU)*MU
      n       <-  length(MU)
      IdY2    <-   rep(1:n, 2)
      MU2    <-  rep(MU,2) 
      Y2     <-  sort(rep(0:1, n))
      D2     <-  MU2*(1-MU2)*matrix(rep(t(Z),2), 2*n,ncol(Z), byrow=TRUE)  
      
      it0 <-2
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      pi02aux   <-   rep(pi0, 2)
      pi02      <-  Spi2$MU 
      D2pi     <- Spi2$D 
      Uic      <- (Y2-MU2)/(MU2*(1-MU2))
      pY       <- MU*Y + (1-MU)*(1-Y)
      pY2      <- MU2*Y2 + (1-MU2)*(1-Y2)
      
      aux00  <-   Uic*pi02*pY2
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc    <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-   pi02*pY2
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic     <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      w2      <-  rep(w, 2)
      I.est   <- t(Z*  (MU)*(1-2*MU)*(1-MU) * (  (Y-MU)/(MU *(1-MU ))  - Y_MU.est ))%*%Z
      
    }
    
    if(link=='log'){                   
      
      MU <-   as.vector(exp( Z%*%bet ))
      D  <- MU*Z	
      I  <- t(Z)%*% (MU*Z) 
      
      Vi      <-   (1-MU)*MU
      n       <-  length(MU)
      IdY2    <-   rep(1:n, 2) 
      MU2     <-  rep(MU,2) 
      Y2      <-  sort(rep(0:1, n))
      w2      <-  rep(w, 2)
      D2      <-  MU2* matrix(rep(t(Z),2), 2*n,ncol(Z), byrow=TRUE)  
      
      it0 <-2 
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      pi02aux   <-   rep(pi0, 2)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2-MU2)/(MU2*(1-MU2))
      pY       <- MU*Y + (1-MU)*(1-Y)
      pY2      <- MU2*Y2 + (1-MU2)*(1-Y2)
      
      aux00  <-   Uic*pi02*pY2
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc    <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-   pi02*pY2
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic     <- cbind( as.numeric(rownames(aux11)),   (aux11))
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      w2      <-  rep(w, 2)
      
      I.est   <- t(Z*  (MU) * (  (Y-MU)/(MU *(1-MU ))  - Y_MU.est ))%*%Z
    }
    
    if(link=='probit'){   Nu <-  as.vector(Z%*%bet)                   
    MU <-  pnorm(Nu) 
    D  <-  dnorm(Nu)*Z		
    
    I  <-  t(Z)%*% (   -Nu*dnorm(Nu)  *Z)
    Vi      <-   (1-MU)*MU
    n       <-  length(MU)
    IdY2    <-   rep(1:n, 2) 
    MU2     <-  rep(MU,2) 
    Y2     <-  sort(rep(0:1, n)) 
    Z2      <-  matrix(rep(t(Z),2), 2*n,ncol(Z), byrow=TRUE)  
    Nu2     <-  as.vector(Z2%*%bet)                   
    MU2     <-  pnorm(Nu2) 
    
    D2      <-  dnorm(Nu2)*Z2		
    
    Xbig     <- matrix(rep(t(X),2), 2*n,ncol(X), byrow=TRUE)
    
    it0 <-2
    
    aa0     <- rep(t(X.PIsNoy),it0)
    nAA     <- ncol(X.PIsNoy)
    AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
    XbigNoy.PI  <- cbind(AA0)
    
    dataBig   <- data.frame(XbigNoy.PI,  Y2)
    colnames(dataBig)   <- colnames(dataS)  
    Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
    
    
    
    
    
    
    nBB    <- ncol(X.PIs.TRUENoy)
    bb0     <-  rep(t(X.PIs.TRUENoy),it0)
    BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
    Xbig.PITRUENoy  <- cbind(BB0)
    
    
    ##############
    ##############
    mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
    pi02Big  <- mod2PI
    
    Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
    
    pi02aux   <-   rep(pi0, 2)
    pi02      <-  Spi2$MU 
    
    D2pi      <- Spi2$D 
    
    Uic   <- (Y2-MU2)/(MU2*(1-MU2))
    pY       <- MU*Y + (1-MU)*(1-Y)
    pY2      <- MU2*Y2 + (1-MU2)*(1-Y2)
    
    aux00  <-   Uic*pi02*pY2
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Uc    <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    aux00  <-   pi02*pY2
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_pic     <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
    w2      <-  rep(w, 2)
    
    I.est   <- - t(Z*    Nu*dnorm(Nu)* (  (Y-MU)/(MU *(1-MU ))  - Y_MU.est ))%*%Z
    
    
    }
    
    
    aux00  <-   pY2*D2*pi02*(((Y2-MU2)/(MU2*(1-MU2))))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
 
    
    Dev.fy <-  - t(D.U.pi[,-1] /(E_pic[,2]^2)   ) %*%D.U.pi[,-1]
    
    aux00  <-   (pY2*(Y2-MU2)/(MU2*(1-MU2)))*(D2pi   ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    Y_MDpi.pi  <- (	Y_MDpi /(E_pic[,2]))[,-1]
    
    aux00  <-   pY2*D2pi
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    E_Dpi.pi  <- (E_Dpi[,-1] /(E_pic[,2] )^2)
    
    dScbet  <-  - t(D)%*%(D*(Y-MU)^2 /((1-MU)^2*MU^2 ))   + I.est - Dev.fy
    
    
    aux00  <-  ( pY2*(Y2- MU2)^2*pi02    )
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Uc22   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
    dScbetEst  <-  - t(D*Uc22est/(MU^2*(1-MU)^2))%*%D     
    
 
    
    
    
    
    
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
    
    dScbetaalp  <- -(  t(D)%*%(Y_MDpi.pi ) - t(D)%*% (	E_Uc[,2]*E_Dpi.pi ) )
    
    dScpi   <- -(  t(D)%*%(Y_MDpi.pi ) - t(D)%*% (	E_Uc[,2]*E_Dpi.pi ) )
    
    Vi     <-  (1 -MU)*(MU )
    Uwi    <-  D*(as.vector(Y-MU)/Vi)  
    
    Sw     <-  colSums(Uwi*w) 
    Uci   <- D*(as.vector((Y-MU)/Vi) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
    
  }
  
  if( dist=='poisson'){  
    itaux      <-  max(Ya) + mean(Ya)
    it         <- round(itaux )+1
    
    
    if(link=='identity' || link=='log' ){   
      MU <-  as.vector(exp(Z%*%bet)  )
      D  <-  MU*Z		
      I  <-  t(Z) %*% (Z* MU^2)
      Vi      <-  MU
       n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      Y2      <-  sort(rep(0:(it-1), n)) 
      paux   <-    dpois(  Y2, MU2   )
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-  MU2*Z2		
      
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2-MU2)/(MU2 )
      
      aux00  <-  Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <- t(Z*      MU* (  (Y-MU)/(MU )  - Y_MU.est ))%*%Z
      
    }
    
    if(link=='sqrt'){     
      MU <-   as.vector(( Z%*%bet )^2)
       
      D  <- 2*sqrt(MU)*Z	
      I  <- t(Z)%*% ( Z	/sqrt(MU)) 
      Vi      <-  MU
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      #Y2      <-  rpois(it*n,  MU2  )
      Y2      <-   sort(rep(0:(it-1), n)) 
      paux   <-    dpois(  Y2, MU2   )
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-  2*sqrt(MU2)*Z2		
      
      
      Xbig     <- matrix(rep(t(X),it), it*n,ncol(X), byrow=TRUE)
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2-MU2)/(MU2 )
      
      aux00  <-  Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <- 2*t(Z*   (  (Y-MU)/(MU )  - Y_MU.est ))%*%Z
      
      
    }
    
    aux00  <-  D2*pi02*paux
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    D.est <-  data.matrix((D_Uc[,-1]/(E_pic[,2])) )
    
    aux00  <-  paux*D2*pi02*Y2/(MU^2)
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc2    <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    D.est2 <-  data.matrix((D_Uc2[,-1]/(E_pic[,2])) )
    
    aux00  <-  D2*paux*pi02*(((Y2-MU2)/(MU2 )))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    aux00  <-  D2*paux*pi02*((((Y2-MU2)/(MU2 ))^2))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U2.pi   <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
    Dev.fy <- t(D.U2.pi[,-1]/(E_pic[,2]) - (D.U.pi[,-1]*E_Uc[,-1]/(E_pic[,2]^2) )  ) %*%D
    
    
    aux00  <-  paux*(Y2-MU2)*(D2pi/MU2   )
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi    <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    
    Y_MDpi.pi  <- (	Y_MDpi /(E_pic[,2]))[,-1]
    
    aux00  <-  D2pi*paux 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi     <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    E_Dpi.pi  <- (E_Dpi /(E_pic[,2]^2))[,-1]
    
    
    
    dScbet  <- -t(D)%*%( D*Y/(MU^2) ) +t(D)%*%(D.est2 )  +I.est -Dev.fy 
    aux00  <-  ( paux*(Y2- MU2)^2*pi02    ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Uc22      <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
    
    dScbetEst  <-  - t(D*Uc22est/MU^2 )%*%D
    
    
    dScpi   <- -t(D)%*%(Y_MDpi.pi ) + t(D)%*% (E_Uc[,2]*E_Dpi.pi )  
    Vi     <-   (MU )
    Uwi    <-  D*(as.vector(Y-MU)/Vi)  
    
    Sw     <-  colSums(Uwi*w) 
    
    Uci   <- D*(as.vector((Y-MU)/Vi) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
  }        
  
  if( dist=='Exponential'){  
    if(link=='identity' || link=='inverse'){ 
      MU <-   as.vector(-1/( Z%*%bet )) 
      D  <-   MU^2 *Z		
      I  <-   t(Z)%*% ((2*MU^3)*Z )
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      # Y2     <-  rexp(it*n, 1/ MU2  )
      SD      <- max(  MU^2)
      
      Y2     <-  sort(rep(seq(0, max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dexp(  Y2,1/ MU2  )
      
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   (MU2^2)*Z2		
      
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2 -MU2)/(MU2^2 )
      
      aux00  <-  Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <-   2*t(Z* MU^3*  (  (Y-MU)/(MU^2 )  - Y_MU.est ))%*%Z
      
    }
    
    if(link=='log'){       
      MU <-  as.vector( exp( Z%*%bet ))
      D  <-   MU *Z	
      I  <-   t(Z)%*% ( Z*MU ) 
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      SD      <- max(  MU^2)
      
      Y2     <-  sort(rep(seq(0, max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dexp(  Y2,1/ MU2  )
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   (MU2)*Z2		
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2-MU2 )/(MU2^2 )
      
      aux00  <-  Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <-  t(Z* MU*  (  (Y-MU )/(MU^2 )  - Y_MU.est ))%*%Z 
    }
    
    aux00  <-    paux*D2*pi02
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    D.est <-  data.matrix((D_Uc[,-1]/(E_pic[,2])) )
    aux00  <-    paux*D2*pi02*(Y2-MU2)/(MU2^3)
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc2<- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    D.est2 <-  data.matrix((D_Uc2[,-1]/(E_pic[,2])) )
    aux00  <-   paux*D2*pi02*(((Y2-MU2)/(MU2^2 )))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi<- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    aux00  <-   paux*D2*pi02*((((Y2-MU2)/(MU2^2 ))^2))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U2.pi <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    Dev.fy <- t(D.U2.pi[,-1]/(E_pic[,2]) - (D.U.pi[,-1]*E_Uc[,-1]/(E_pic[,2]^2) )  ) %*%D
    
    aux00  <-   (paux*(Y2-MU2))*(D2pi/(MU2^2)   ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    Y_MDpi.pi  <- (	Y_MDpi /(E_pic[,2]))[,-1]
    
    aux00  <-   paux*D2pi 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    E_Dpi.pi  <- (E_Dpi /(E_pic[,2]^2))[,-1]
    
    
    
    dScbet  <- -t(D)%*%( D*(Y-MU)/(MU^3) ) +t(D)%*%(D.est2 )  +I.est -Dev.fy
    
    aux00  <-    (  paux*(Y2- MU2)^2*pi02    )
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Uc22  <-  cbind( as.numeric(rownames(aux11)),   (aux11))
    
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
    
    dScbetEst  <-  - t(D*Uc22est/MU^4 )%*%D
    
    dScpi   <- -t(D)%*%(Y_MDpi.pi ) + t(D)%*% (E_Uc[,2]*E_Dpi.pi ) 
    
    Vi     <-  (MU^2 )
    Uwi    <-  D*(as.vector(Y-MU)/Vi)  
    
    Sw     <-  colSums(Uwi*w) 
    
    Uci   <- D*(as.vector((Y-MU)/Vi) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
  } 
  
  if( dist=='Gamma'){  
    if(link=='identity' || link=='inverse'){ 
      MU <- as.vector(-1/( Z%*%bet )) 
      D  <- MU^2 *Z	
      I  <- t(Z)%*% ((2*MU^3)*Z) 	
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      # Y2     <-  rexp(it*n, 1/ MU2  )
      SD      <- sd(Y)
      Y2     <-  sort(rep(seq(10^(-10), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dgamma(  Y2,shape= 1, scale= MU2  )
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   (MU2^2)*Z2		
      
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2 -MU2)/(MU2^2 )
      
      aux00  <-  Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <-   2*t(Z* MU^3*  (  (Y-MU)/(MU^2 )  - Y_MU.est ))%*%Z
      
    }
    
    if(link=='inverse2'){                   
      MU <-  as.vector(1/( Z%*%bet ))
      D  <- -MU^2 *Z	 	
      I  <- -t(Z)%*% ((-2*MU^3)*Z) 	
      Iw  <- -t(Z)%*% ((-2*MU^3)*Z*w) 
      
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      # Y2     <-  rexp(it*n, 1/ MU2  )
      SD      <- sd(Y)
      Y2     <-  sort(rep(seq(10^(-10), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dgamma(  Y2,shape= 1, scale=  MU2  ) #dgamma(  Y2,shape= MU2^2/SD^2, scale= SD^2/MU2  )
      
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   -(MU2^2)*Z2		
      
      it0 <-it
      
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2 -MU2)/(MU2^2 )
      
      aux00  <-  Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <- 2*t(Z* MU^3*  (  (Y-MU)/(MU^2 )  - Y_MU.est ))%*%Z
      
      
    }
    
    if(link=='log'){      
      MU <- as.vector(exp(Z%*%bet)  )
      D  <- MU*Z		
      I  <- t(Z)%*% ( MU*Z ) 
      Vi      <-  MU^2
      n       <-  length(MU)
      IdY2    <-  rep(1:n, it) 
      MU2     <-  rep(MU,it) 
      # Y2     <-  rexp(it*n, 1/ MU2  )
      SD      <- sd(Y)
      Y2     <-  sort(rep(seq(10^(-10), max(MU+wth*SD), length.out=it), n)) 
      paux   <-  ( (-min(MU-wth*SD) + max(MU+wth*SD))/(it-1))* dgamma(  Y2,shape= 1, scale= MU2  )
      
      w2      <-  rep(w, it)
      Z2      <-  matrix(rep(t(Z),it), it*n,ncol(Z), byrow=TRUE)  
      D2      <-   (MU2)*Z2		
      
      Xbig     <- matrix(rep(t(X),it), it*n,ncol(X), byrow=TRUE)
      
      it0 <-it
      
      aa0     <- rep(t(X.PIsNoy),it0)
      nAA     <- ncol(X.PIsNoy)
      AA0     <- matrix(aa0, it0*n,nAA, byrow=TRUE)
      XbigNoy.PI  <- cbind(AA0)
      
      dataBig   <- data.frame(XbigNoy.PI,  Y2)
      colnames(dataBig)   <- colnames(dataS)  
      Xbig.PI  <-  cbind(model.matrix(fX.PI, data= dataBig      ))
      
      
      
      
      
      
      nBB    <- ncol(X.PIs.TRUENoy)
      bb0     <-  rep(t(X.PIs.TRUENoy),it0)
      BB0     <-  matrix(bb0, it0*n, nBB, byrow=TRUE)
      Xbig.PITRUENoy  <- cbind(BB0)
      
      
      ##############
      ##############
      mod2PI   <-  pFUN0( Xbig.PITRUENoy, Y2) 
      pi02Big  <- mod2PI
      
      Spi2    <- SWpicalaux(  bet.PI, Xbig.PI,  pi02Big,  distance=distance  )
      
      
      pi02aux   <-   rep(pi0, it)
      pi02      <-  Spi2$MU 
      
      D2pi      <- Spi2$D 
      
      Uic   <- (Y2 -MU2)/(MU2^2 )
      
      aux00  <-  Uic*pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_Uc   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      aux00  <-  pi02*paux
      aux11  <-  rowsum( aux00 , as.factor(IdY2))
      E_pic   <- cbind( as.numeric(rownames(aux11)),   (aux11))
      
      Y_MU.est <-  (E_Uc[,2])/(E_pic[,2]) 
      
      I.est   <-  t(Z* MU*  (  (Y -MU)/(MU^2 )  - Y_MU.est ))%*%Z
      
      
      
      
    }
    
    aux00  <- paux*D2*pi02
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    D.est <-  data.matrix((D_Uc[,-1]/(E_pic[,2])) )
    aux00  <- paux*D2*pi02*(Y2-MU2)/(MU2^3)
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D_Uc2 <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    D.est2 <-  data.matrix((D_Uc2[,-1]/(E_pic[,2])) )
    aux00  <- paux*D2*pi02*(((Y2-MU2)/(MU2^2 )))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U.pi <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    aux00  <- paux*D2*pi02*((((Y2-MU2)/(MU2^2 ))^2))
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    D.U2.pi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    Dev.fy <- t(D.U2.pi[,-1]/(E_pic[,2]) - (D.U.pi[,-1]*E_Uc[,-1]/(E_pic[,2]^2) )  ) %*%D
    
    aux00  <-   (paux*(Y2-MU2))*(D2pi/(MU2^2)   ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Y_MDpi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    
    Y_MDpi.pi  <- (	Y_MDpi /(E_pic[,2]))[,-1]
    aux00  <-   paux*D2pi
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    E_Dpi  <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    E_Dpi.pi  <- (E_Dpi /(E_pic[,2]^2))[,-1]
    
    
    
    dScbet  <- -t(D)%*%( D*(Y-MU)/(MU^3) ) +t(D)%*%(D.est2 )  +I.est -Dev.fy
    aux00  <-   (  paux*(Y2- MU2)^2*pi02    ) 
    aux11  <-  rowsum( aux00 , as.factor(IdY2))
    Uc22    <- cbind( as.numeric(rownames(aux11)),   (aux11))
    
    Uc22est    <-   (( Uc22[,-1] /(E_pic[,2])))
    
    dScbetEst  <-  - t(D*Uc22est/MU^4 )%*%D
    dScpi   <- -t(D)%*%(Y_MDpi.pi ) + t(D)%*% (E_Uc[,2]*E_Dpi.pi ) 
    
    Vi     <-   (MU^2 )
    Uwi    <-  D*(as.vector(Y-MU)/Vi)  
    
    Sw     <-  colSums(Uwi*w) 
    
    
    
    Uci   <- D*(as.vector((Y-MU)/Vi) -	as.vector(Y_MU.est )) 
    Sc.s    <- colSums(Uci) 
    
  }   
  
  return(list(MU=MU,Sc.s=Sc.s, Sw=Sw, Uwi=	Uwi, 	 w=	 w  , Uci=Uci,    ids= ids,   
              D,   dScbet=dScbet, dScpi=dScpi, E_Uc=E_Uc, pis=pi0, D.U.pi =D.U.pi, id.sam=id.sam ,  dScbetEst = dScbetEst 
  ))
  
}
