# ids= ids, by default from 1:N  
# Ya = The response vector in the population. If not avaiable, then    
# pi0a = Probabilities
# bet= 
# Za =
# dist = 
# link  =
# R.PI = 
# X.PI = 
# dist.PI='binomial', 
# link.PI='identity' , 
# ids.PI=1:length(Ya), 
# eps=1E-10 , 
# simulta=TRUE 


#ss<-CgeeAlp(    ids=1:length(Ya), Ya,   pi0a,bet = rep(1, ncol(Za)),   Za, dist=dist, link='log',     R.PI,  X.PI,  dist.PI='binomial', link.PI='identity' , ids.PI=1:length(Ya), eps=1E-10 ,  simulta=TRUE ) 


 

CMLest  <- function(    ids=1:length(Ya), Ya,   pi0a,bet = NULL,   Za, dist='gaussian', link='identity',   
                         R.PI,  X.PINoy,  dist.PI='binomial', link.PI='identity' , eps=1E-10 ,  bet.PI =NULL,   fX.PI =  fX.PI ) 
  
{   
  simulta  <- TRUE
  ids.PI   <- ids
  if(  is.null(bet)) {stop('No starting values provided for  bet')}
  if(class( fX.PI)!='formula' ){ stop('fX.PI has to be a formula')  }
 
  if( length(Ya)!= nrow(Za)  ){ stop('Ya and Za has to be the same length.   Za should have NAs in the missing values')  }
  if( nrow(X.PINoy)!= nrow(Za)  ){ stop('X.PINoy and Za has to be the same length.   Za should have NAs in the missing values')  }
  if( length(Ya)!= nrow(X.PINoy)  ){ stop('Ya and X.PINoy has to be the same length')  }
  if(!(dist=='gaussian'|| dist=='poisson'|| dist=='Gamma' || dist=='binomial')){ stop('dist has to be: gaussian,poisson, Gamma or binomial')}
  if(!link.PI%in%c('logit', 'log', 'probit')){stop('link for weights  has to be: logit, log or probit')}
  
  
  
  
  
  
  R              <- R.PI 
  dataS     <- data.frame(X.PINoy,  Ya) 
  
  X.PI     <- cbind(model.matrix(fX.PI , data= dataS))
  
  
  R               <-  R.PI
  
  if(is.null(bet.PI) & simulta==FALSE){  
    stop("bet.PI is needed when simulta=FALSE")
  }
  
  if((!is.null(bet.PI)) & simulta==TRUE){  
    stop("bet.PI is not needed when simulta=TRUE")
  }
  
  if((!is.null(bet.PI)) & simulta==FALSE){  
    
    pi0aTRUE   <- pi0a 
    alp0    <-   bet.PI
    alp0.c <- alp0   
    alp0TRUE    <-   bet.PI
    alp0.cTRUE  <- alp0  
  }
  
  if(is.null(bet.PI) & simulta==TRUE){  
    bet.PI        <- coefficients(glm(R.PI ~ 0+X.PI, family=dist.PI ))
    pi0aTRUE   <- pi0a 
    alp0    <-   bet.PI
    alp0.c <- alp0   
    
    if(     link.PI=='log' & dist.PI=='binomial')
    { 
      start0p  <- alp0 
      alp0h  <-  log( mean(R)/mean(exp(X.PI[ ,-1]%*%( alp0  [-1]))))
      alp0ah <- - max(X.PI[ ,-1]%*%(start0p [-1])) 
      start0p[1]  <- min(alp0ah, alp0h)
      alp0   <-   start0p
      alp0.c   <-   alp0   
    } 
    
  }
  
  
  
  
  
  
  
  
  
  beta0   <- bet
  
  if(     link=='log' & dist=='binomial')
  {
    
    mod00    <-    glm(Ya[R.PI==1]~0+Za[R.PI  ==1,] , weights=1/pi0a[R==1] , family=quasibinomial   )   
    start.Beta        <- coefficients( mod00 )
    beta000           <- min( - abs( max( Za[R.PI==1, ]%*%start.Beta )) -0.1, start.Beta[1])
    start.Beta[1]     <- beta000
    beta0   <-   start.Beta
    
    
    
    
    
  }
  
  
  
  theta1  <- c(beta0,alp0)
  theta1.c  <- c(beta0,alp0.c)
  
  
  
  
  
  
  
  
  
  
  
  
  eps0    <- eps*100 
  
  if(simulta  == TRUE ){  simul  <-1 }
  
  if(simulta  == FALSE ){  simul  <-0 }
  
  cont <- 1
  
   
  
  while(eps <  eps0  ){ 
    
     
 
    bet.PI  <- theta1[(ncol(Za)+1):(ncol(Za)+ ncol(X.PI))] 
    bet     <-  theta1[1:ncol(Za)]  
   
    bet.PI.c  <-  theta1.c[(ncol(Za)+1):(ncol(Za)+ ncol(X.PI))] 
    bet.c     <- theta1.c[1:ncol(Za)]
    
    
    Spi      <- SWpi( ids=ids.PI , R.PI, bet.PI, X.PI,  dist=dist.PI, link=link.PI )
    Upi      <- Spi$Uwi
    Swpi      <- Spi$SS
    Dpi      <- Spi$D
    pi.i     <- Spi$MU  
    dUpi     <- Spi$dU
    idpi     <- Spi$id.sam
    pi0a.w     <- Spi$pi0 
    
    
    Spi.c      <- SWpi( ids=ids.PI , R.PI, bet.PI.c, X.PI,  dist=dist.PI, link=link.PI )
    Upi.c      <- Spi.c$Uwi
    Swpi.c     <- Spi.c$SS
    Dpi.c      <- Spi.c$D
    pi.i.c     <- Spi.c$MU 
    dUpi.c     <- Spi.c$dU
    idpi.c     <- Spi.c$id.sam
    pi0a.c     <- Spi.c$pi0 
    
    Sbet     <-  SW(Ya,R, pi0a.w,bet, Za, dist , link , ids=ids )
    SbetC     <- Sc(Ya,R, pi0a.c,bet.c,  Za, dist , link ,   bet.PI.c  , 
                    X.PINoy,  dist.PI, link.PI, ids=ids.PI, it=50,   fX.PI =  fX.PI )
    
    
    Ubet.c      <- SbetC$Uci
    Swbet.c     <- SbetC$Sc.s
    Dbet.c      <- SbetC$D
    mu.i.c      <- SbetC$MU
    dUbet.c     <- SbetC$dScbet 
    
    
    
    
    
    
    dSw.alp.c   <- t(SbetC$dScpi)
    
    
    
    aux         <- cbind(dUbet.c   ,  t(dSw.alp.c*(simul)  ) )
    aux2        <- cbind(  dSw.alp.c*0  , dUpi.c )
    D.all.c     <- rbind(aux, aux2 )
    
   
    Ubet      <- Sbet$Uwi
    Swbet     <- Sbet$Sw
    Dbet      <- Sbet$D
    mu.i      <- Sbet$MU
    dUbet     <- Sbet$dUw
    idbet     <- Sbet$id.sam
    dSw.alp   <- - t( (Dpi /as.vector(pi.i^2) )[idbet, ] )%*%(Ubet)
    aux        <- cbind(dUbet ,  t(dSw.alp )*(simul) )
    aux2       <- cbind(  dSw.alp*0   , dUpi  )
    D.all      <- rbind(aux, aux2 ) 
    
 
    
    
    
    ### derivative of Sw with respect to alpha
    ### derivtive Spi with respect to beta. 
    
    dUw.a  <- solve( t(D.all)%*% (D.all))%*%t(D.all)
    
    dUw.a.c  <- solve(t(D.all.c)%*% (D.all.c))%*%t(D.all.c) 
     
    Cond1    <- Dbet*(Ya[R.PI==1]- mu.i )*Sbet$w
    Dev1      <- -t(Dbet* Sbet$w)%*% Dbet
    dUw0      <-  D.all*0
    dUw0[1:length(bet.c),1:length(bet.c) ] <- solve(Dev1)
    
    if(cont < 3){   
      
      theta0  <- theta1
      theta1  <- theta0 -  (dUw0) %*%c( colSums(Cond1) ,  Swpi*0)   
      theta1.c  <- theta1 
    }
    
    if(cont >2){  
      theta0  <- theta1
      theta1  <- theta0 -  (dUw.a) %*%c(Swbet ,  Swpi*simul) 
      theta0.c  <- theta1.c
      theta1.c  <- theta0.c  -  dUw.a.c %*%c(Swbet.c,  Swpi.c*simul) 
      eps0 <- max( max(abs(theta1 -theta0)) , max(abs(theta1.c -theta0.c)))
      
    }
    cont <-cont+1
    if(cont >= 100){stop(paste('Algorithm doesnot converge, epsilon: ',  eps0))}
     
  }
  
  
  
  alp0    <-  theta1[(ncol(Za)+1):(ncol(Za)+ ncol(X.PI))] 
  beta0   <-  theta1[1:ncol(Za)]
  alp0.c    <-  theta1.c[(ncol(Za)+1):(ncol(Za)+ ncol(X.PI))] 
  beta0.c   <-  theta1.c[1:ncol(Za)]
  
  dUbet.cE     <-  -t(SbetC$Uci)%*%(SbetC$Uci)
  
  
  auxE         <- cbind(dUbet.cE  ,  t(dSw.alp.c *(simul) ) )
  aux2E        <- cbind(  dSw.alp.c*0  , dUpi.c)
  D.all.cE      <- rbind(auxE, aux2E )
  
  
  
  
  
  
  ww      <- Sbet$w
  
  
  mU      <-  colSums(Ubet*ww)/sum(ww)
  
  # Ubet    <- Ubet  -matrix(  mU, nrow(Ubet), ncol(Ubet) , byrow=T)
  
  VI      <- t(Ubet*ww)%*% Ubet
  Deltad   <-  (  ww^2-ww)
  
  
  VII        <-  t(Ubet*Deltad  )%*%Ubet
  
  
  VIpi       <-  t(Upi ) %*%(Upi ) 
  Cbetpi     <-  t(Ubet*ww   )%*%Upi[idbet,]*(simul)      
  
  
  
  
  meatT    <- rbind( cbind(VI+VII, Cbetpi*simul ) , cbind(t(Cbetpi*simul ), VIpi) ) 
  covT     <-  (solve( (D.all)))%*%(meatT)%*%solve(t(D.all))
  
  
  
  ## Varince estimation for Cond Lik
  dUbet.c     <- SbetC$dScbetEst
  aux         <- cbind(dUbet.c   ,  t(dSw.alp.c )*simul)
  aux2        <- cbind(  dSw.alp.c*0 , dUpi.c)
  D.all.c     <- rbind(aux, aux2 )
  
  
  E_Ucpi     <- SbetC$D.U.pi[,-1]
  pis.c      <- as.vector(SbetC$pis)
  Ubet.cpi   <- Ubet.c*pis.c
  
  VI.c        <-  t((Ubet.cpi-E_Ucpi )/pis.c) %*% (Ubet.cpi-E_Ucpi )
  VII.c       <-     - dUbet.c  - VI.c   
  VIpi.c     <-  t(Upi.c ) %*%(Upi.c ) 
  Cbetpi.c     <- t( Ubet.c  )%*%Upi.c[idbet,]*(simul) 
  meatT.c     <-   rbind( cbind(VI.c+VII.c, Cbetpi.c*simul ) , cbind(t(Cbetpi.c*simul ), VIpi.c) ) 
  covT.cA     <-  (solve( (D.all.c) ))%*%(meatT.c)%*%solve(t(D.all.c))
  
  
  E_Ucpi     <- SbetC$D.U.pi[,-1]
  pis.c        <- SbetC$pis
  Ubet.cpi   <- Ubet.c*pis.c
  
  VI.c        <-  t((Ubet.c  ) ) %*% (Ubet.c * pis.c    )
  VII.c       <- t( Ubet.c * ( 1-pis.c) ) %*% (Ubet.c )
  VIpi.c       <- t(Upi.c ) %*%(Upi.c ) 
  Cbetpi.c     <-  t( Ubet.c   )%*%Upi.c[idbet,]*(simul) 
  meatT.c     <-   rbind( cbind(VI.c+VII.c, Cbetpi.c*simul ) , cbind(t(Cbetpi.c*simul ), VIpi.c) ) 
  covT.c     <-  (solve( (D.all.cE) ))%*%(meatT.c)%*%solve(t(D.all.cE))
  
  
  
  sdWL  <- sqrt(diag(covT))[ 1: length(beta0)]  
  t.val  <- beta0/sdWL  
  p.val  <- 2*(1- pnorm(t.val))
  
  sdCL  <- sqrt(diag(covT.c))[ 1: length(beta0)]  
  t.val.c  <- beta0.c/sdCL
  p.val.c  <- 2*(1- pnorm(t.val.c))
  
  
  
  coeffWL   <- cbind(beta0, sdWL, t.val,p.val )
  coeffCL   <- cbind(beta0.c, sdCL, t.val.c,p.val.c )
  
  colnames(coeffWL) <- c('Coeff','se','t.val', 'p.val')
  colnames(coeffCL) <- c('Coeff','se','t.val', 'p.val') 
  
  rownames(coeffWL) <-   rownames(coeffCL)  <- colnames(Za)
  
  
  
  
  return(  list (  coeffWL=coeffWL, coeffCL=coeffCL, alp=alp0,   alp.c=alp0.c,   eps=eps,  covT=covT ,  covT.c=covT.c ) )
  
   
}




