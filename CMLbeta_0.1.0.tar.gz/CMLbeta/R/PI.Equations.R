 


#ids=The unique ids in the population (this is a vector of size N) ,
#R.PI= The binary  sampling indicator variable  (size N), 
#bet.PI= Starting values for coefficients, 
#X.PI = Matrix of available information to estimate the coefficients  (Size N \times q),  
#dist=This is onyl avaiable for 'binomial' family, 
#link= this can be logit, log or probit.  




SWpi        <- function(  ids=1:length(R.PI), R.PI, bet.PI, X.PI,  dist='binomial', link='identity' ){  
X.PI        <- cbind(X.PI )
names(R.PI) <- rownames(X.PI)  <- ids ;
id.sam      <- ids[R.PI==1] 
 
if( dist=='binomial'){  
  if(link=='identity' || link=='logit' ){ 
    NU  <- X.PI%*%bet.PI
    MU <- as.vector(1/(1+exp(-NU)) ) 
    D   <- (MU*(1-MU))*X.PI
    dU  <- -t(D)%*%(  X.PI)  
    }
    
    if(link=='log'){                        
      NU  <- X.PI%*%bet.PI
      MU <-  as.vector(exp(NU )) 
      D  <- MU*X.PI	
      aux0   <- (as.vector(R.PI-MU)/(  (1-MU)^2  ) -1/(1-MU))
      aux1   <- ( aux0*X.PI) 
      dU  <-  t(D)%*%aux1
    }
    
    if(link=='probit'){                     
    NU  <-  as.vector( X.PI%*%bet.PI)
    MU <- as.vector(pnorm(NU) ) 
    D  <- as.vector(dnorm(NU))*X.PI	 
    aux1 <- ( ( as.vector(  NU)  * as.vector( dnorm((NU) )) )*( ((R.PI - MU)/(MU*(1-MU)))* MU) * X.PI)
    aux2 <- (( -1/(MU*(1-MU))- ((R.PI - MU)*(1-2*MU))/((MU*(1-MU))^2) )*D )
    dU  <- t(X.PI)%*%aux1 + t(D)%*%aux2 
    }
    
    Vi    <- (1 -MU)*(MU )  
    Uwi   <- D*(as.vector(R.PI-MU)/Vi)  
    SS    <- colSums(Uwi ) 
  }


 
 
  auxb      <-(R.PI-MU)
  dU.alp   <-  auxb/(MU*(1-MU)) 
  list(Uwi=Uwi,SS=SS,D=D,  MU= MU,  dU=dU, ids=ids, id.sam=id.sam, pi0= MU )
    
}   







SWpical <- function(  ids=1:length(R.PI),R.PI, bet.PI, X.PI, pi0a,  distance='chi' ){  
X.PI        <- cbind(X.PI ) 
names(R.PI)  <- rownames(X.PI)  <- ids ;
id.sam   <-ids[R.PI==1] 
   
  
 W0a <- 1/as.vector(pi0a)
 
    if(distance== 'chi' ){ 
    NU     <- X.PI%*%bet.PI
    F.alp    <-  1+  as.vector( NU ) 
    F1.alp   <- X.PI
  }
    
  if( distance== 'poisson'){   
    NU       <- X.PI%*%bet.PI
    F.alp    <-  as.vector(exp( NU ) )
    F1.alp   <-  as.vector(exp( NU ) )*X.PI }
    
    U.cal    <- (R.PI*F.alp*W0a- 1)*X.PI 
    auxa     <-   t( F1.alp*(R.PI* W0a))
    dU.cal   <-  auxa%*%X.PI
    SS <- colSums(U.cal ) 
   
     w.i  <- F.alp*W0a
     pi.i <-1/w.i
     D  <-   -F1.alp*as.vector(pi.i)/(as.vector(F.alp)^2)
  
      list( U.cal= U.cal,SS=SS,dU.cal=dU.cal, F.alp= F.alp, F1.alp=F1.alp, ids=ids, id.sam=id.sam, pi.i=pi.i,D=D  ) }   







##################



SWpiaux <- function(  bet.PI, X.PI,  dist='binomial', link='identity'  ){  
  X.PI        <- cbind(X.PI ) 
  
  if( dist=='binomial'){  
    if(link=='identity' || link=='logit' ){ 
    NU <- X.PI%*%bet.PI
    MU <- as.vector(1/(1+exp(-NU)) ) 
    Vi    <- (1 -MU)*(MU )  
    D   <- (MU*(1-MU))*X.PI }
    
    if(link=='log'){                       
    NU <- X.PI%*%bet.PI
    MU <-  as.vector(exp(NU ))
    Vi    <- (1 -MU)*(MU )  
    D  <- MU*X.PI	 
   }
    
    if(link=='probit'){                     
      NU <- X.PI%*%bet.PI
      MU <- as.vector(pnorm(NU) )
     Vi    <- (1 -MU)*(MU )  
     D  <- as.vector(dnorm(NU))*X.PI	
      }
    
 
  }
  
  
 
  list( D=D,  MU= MU  )
  
}   







SWpicalaux <- function(   bet.PI, X.PI, pi0a,  distance='chi'  ){  
  X.PI        <- cbind(X.PI ) 
  
  W0a <- 1/as.vector(pi0a)
  
  if(distance== 'chi' ){ 
    NU <- X.PI%*%bet.PI 
    F.alp    <-  1+ as.vector(  NU  ) 
     F1.alp   <- X.PI
  }
  
  if( distance== 'poisson'){    
    NU <- X.PI%*%bet.PI 
    F.alp    <-  as.vector(exp(  NU ) )
     F1.alp   <-  as.vector(exp(  NU ) )*X.PI
     
  }
   w.i  <- F.alp*W0a
  pi.i <-1/w.i
  D <- (-1/w.i^2)* F1.alp *W0a
  MU <- 1/w.i
  list( D=D,  MU= MU , F.alp= F.alp, F1.alp=F1.alp,  pi.i=pi.i )
  
}   


 