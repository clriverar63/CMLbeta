



CMLcal  <- function(  ids=1:length(Ya),  Ya, pi0a,bet = NULL,  Za, dist='gaussian', link='identity',
                          R.PI,  X.PINoy , distance='chi',    eps=1E-10,    bet.PI =NULL,     fX.PI=formula(~ 1),   pFUN0 ,X.PI.TRUENoy) 
  
{
  ids.PI   <- ids
  if(  is.null(bet)) {stop('No starting values provided for  bet')}
  if(class( fX.PI)!='formula' ){ stop('fX.PI has to be a formula')  }
  if( !is.function(pFUN0)  ){ stop('pFUN0 has to be a function')  }
  
  if( length(Ya)!= nrow(Za)  ){ stop('Ya and Za has to be the same length.   Za should have NAs in the missing values')  }
  if( nrow(X.PINoy)!= nrow(Za)  ){ stop('X.PINoy and Za has to be the same length.   Za should have NAs in the missing values')  }
  if( length(Ya)!= nrow(X.PINoy)  ){ stop('Ya and X.PINoy has to be the same length')  }
  if(!(dist=='gaussian'|| dist=='poisson'|| dist=='Gamma' || dist=='binomial')){ stop('dist has to be: gaussian,poisson, Gamma or binomial')}
  if(!distance%in%c('chi', 'poisson')){stop('distance has to be either chi or poisson')}
      
 
  
   beta0   <- bet
  simulta=TRUE  
  dataS     <- data.frame(X.PINoy,  Ya) 
  X.PI     <- cbind(model.matrix(fX.PI , data= dataS))
  
   
  R               <-  R.PI
   
  
  if((!is.null(bet.PI)) ){  
    pi0aTRUE   <- pi0a 
    alp0    <-   bet.PI
    alp0.c <- alp0   
    alp0TRUE    <-   bet.PI
    alp0.cTRUE  <- alp0  
  }
  
  if(is.null(bet.PI) ){  
    bet.PI        <- coefficients(glm(R.PI ~ 0+X.PI, family=binomial ))*0-0.01
    pi0aTRUE   <- pi0a 
    alp0    <-   bet.PI
    alp0.c <- alp0   
    
 
    
  }
  
  
  
  
  
  if(     link=='log' & dist=='binomial')
  {
    
    mod00    <-    glm(Ya[R.PI==1]~0+Za[R.PI  ==1,] , weights=1/pi0a[R==1] , family=quasibinomial   )   
    start.Beta        <- coefficients( mod00 )
    beta000           <- min( - abs( max( Za[R.PI==1, ]%*%start.Beta )) -0.1, start.Beta[1])
    start.Beta[1]     <- beta000
    beta0   <-   start.Beta
  }
  
  
  theta1  <- c(beta0,alp0)
  theta1.c  <- c(beta0,alp0.c)
  
  
  
  
  
  eps0    <- eps*100 
  simul   <- 0 
  if(simulta  == TRUE ){  simul  <-1 }
  if(simulta  == FALSE ){  simul  <-0 }
  
  cont <- 1
  
  
  while(eps <  eps0  ){ 
    
    
    alp0    <-  theta1[(ncol(Za)+1):(ncol(Za)+ ncol(X.PI))] 
    beta0   <-  theta1[1:ncol(Za)]  
    alp0.c    <-  theta1.c[(ncol(Za)+1):(ncol(Za)+ ncol(X.PI))] 
    beta0.c   <-  theta1.c[1:ncol(Za)]  
    
    
    bet.PI  <- alp0
    bet     <- beta0
    
    bet.PI.c  <- alp0.c
    bet.c     <- beta0.c
    
     
    
    
    Spi      <- SWpical(  ids=ids.PI, R.PI, bet.PI, X.PI, pi0a,  distance  )
    Upi      <- Spi$U.cal
    Swpi      <- Spi$SS
    Dpi      <- Spi$D 
    dUpi     <- Spi$dU.cal
    idpi     <- Spi$id.sam
    
    pi.i     <- Spi$pi.i*(simul) + (1-simul)*pi0a
    
    
    
    Spi.c      <- SWpical(ids=ids.PI, R.PI, bet.PI.c, X.PI, pi0a,  distance  )
    Upi.c      <- Spi.c$U.cal
    Swpi.c     <- Spi.c$SS
    Dpi.c      <- Spi.c$D
    dUpi.c     <- Spi.c$dU
    idpi.c     <- Spi.c$id.sam
    pi0a.c     <- Spi.c$pi.i*(simul) + (1-simul)*pi0a
    
    Sbet      <-  SW(Ya,R, pi.i,bet,  Za, dist , link , ids=ids )
    
    SbetC     <-  ScCal(Ya,R, pi0a.c,bet.c,  Za, dist , link ,   bet.PI.c, 
                        X.PINoy,  distance , it=50,   X.PI.TRUENoy= X.PI.TRUENoy , pFUN0 =pFUN0 ,   fX.PI =  fX.PI )
    
    
    Ubet.c      <- SbetC$Uci
    Swbet.c     <- SbetC$Sc.s
    Dbet.c      <- SbetC$D
    mu.i.c      <- SbetC$MU
    dUbet.c     <- SbetC$dScbet
    idbet.c     <- SbetC$id.sam
    dSw.alp.c   <- t(SbetC$dScpi)
    pi.i.cs     <- Spi.c$pi.i[idbet.c]
    pi.is       <- Spi$pi.i[idbet.c]
    
    dUbet.c     <- SbetC$dScbet 
    
    dSw.alp.c   <- t(SbetC$dScpi)*(simul) 
    
    
    aux         <- cbind(dUbet.c   ,  t(dSw.alp.c )*simul)
    aux2        <- cbind(  dSw.alp.c*0 , dUpi.c)
    D.all.c     <- rbind(aux, aux2 )
    
    
    Ubet      <- Sbet$Uwi
    Swbet     <- Sbet$Sw
    Dbet      <- Sbet$D
    mu.i      <- Sbet$MU
    dUbet     <- Sbet$dUw
    idbet     <- Sbet$id.sam
    pi.i      <- Spi$pi.i[idbet]
    
    w0        <- 1/pi0a[idbet]
    dSw.alp   <-   t(Spi$F1.alp [idbet, ] )%*%(Ubet*w0)*(simul) 
    
    
    aux        <- cbind(dUbet ,  t(dSw.alp ))
    aux2       <- cbind(  dSw.alp*0 , dUpi)
    D.all      <- rbind(aux, aux2 )
    
    
    
    ### derivative of Sw with respect to alpha
    ### derivtive Spi with respect to beta. 
    
    
    dUw.a  <- solve( t(D.all)%*% (D.all))%*%t(D.all)
    
    dUw.a.c  <- solve(t(D.all.c)%*% (D.all.c))%*%t(D.all.c) 
    
    
    Cond1    <- Dbet*(Ya[R.PI==1]- mu.i )*Sbet$w
    Dev1      <- -t(Dbet* Sbet$w)%*% Dbet
    dUw0      <-  D.all*0
    dUw0[1:length(bet.c),1:length(bet.c) ] <- solve(Dev1)
    
    if(cont < 3){   
      
      theta0  <- theta1
      theta1  <- theta0 -  (dUw0) %*%c( colSums(Cond1) ,  Swpi*0)   
      theta1.c  <- theta1 
    }
    
    if(cont >2){  
      theta0  <- theta1
      theta1  <- theta0 -  (dUw.a) %*%c(Swbet ,  Swpi*simul) 
      theta0.c  <- theta1.c
      theta1.c  <- theta0.c  -  dUw.a.c %*%c(Swbet.c,  Swpi.c*simul) 
      eps0 <- max( max(abs(theta1 -theta0)) , max(abs(theta1.c -theta0.c)))
      
    }
  
     
    
    cont <-cont+1
    if(cont >= 100){stop(paste('Algorithm does not converge, epsilon: ',  eps0))}
  }
  
  alp0    <-  theta1[(ncol(Za)+1):(ncol(Za)+ ncol(X.PI))] 
  beta0   <-  theta1[1:ncol(Za)]
  alp0.c    <-  theta1.c[(ncol(Za)+1):(ncol(Za)+ ncol(X.PI))] 
  beta0.c   <-  theta1.c[1:ncol(Za)]
  
  
  
  
  dUbet.cE     <-  -t(SbetC$Uci)%*%(SbetC$Uci)
  
  
  auxE         <- cbind(dUbet.cE  ,  t(dSw.alp.c *(simul) ) )
  aux2E        <- cbind(  dSw.alp.c*0  , dUpi.c)
  D.all.cE      <- rbind(auxE, aux2E )
  
  
  dUbet.c     <- SbetC$dScbetEst
  aux         <- cbind(dUbet.c   ,  t(dSw.alp.c )*simul)
  aux2        <- cbind(  dSw.alp.c*0 , dUpi.c)
  D.all.c     <- rbind(aux, aux2 )
  
  
  ww      <- Sbet$w
  
  
  ## Variance for weighted likelihood. 
  
  VI      <- t(Ubet*ww)%*% Ubet
  Deltad   <-  (  ww^2-ww)
  VII     <-  t(Ubet*Deltad  )%*%Ubet
  VIpi   <-  t(Upi ) %*%(Upi ) 
  Cbetpi  <- t(Ubet*ww   )%*%Upi[idbet,]*(simul) 
  
  
  
  meatT    <- rbind( cbind(VI+VII, Cbetpi*simul ) , cbind(t(Cbetpi*simul ), VIpi) ) 
  covT     <-  (solve( (D.all)))%*%(meatT)%*%solve(t(D.all))
  
  
  
  
  
  
  ## Varince estimation for Cond Lik
  dUbet.c     <- SbetC$dScbetEst
  aux         <- cbind(dUbet.c   ,  t(dSw.alp.c )*simul)
  aux2        <- cbind(  dSw.alp.c*0 , dUpi.c)
  D.all.c     <- rbind(aux, aux2 )
  
  
  E_Ucpi     <- SbetC$D.U.pi[,-1]
  pis.c      <- SbetC$pis
  Ubet.cpi   <- Ubet.c*pis.c
  
  VI.c        <-  t((Ubet.cpi-E_Ucpi )/pis.c) %*% (Ubet.cpi-E_Ucpi )
  VII.c       <-     - dUbet.c  - VI.c   
  VIpi.c     <-  t(Upi.c ) %*%(Upi.c ) 
  Cbetpi.c     <- t( Ubet.c  )%*%Upi.c[idbet,]*(simul) 
  meatT.c     <-   rbind( cbind(VI.c+VII.c, Cbetpi.c*simul ) , cbind(t(Cbetpi.c*simul ), VIpi.c) ) 
  covT.cA     <-  (solve( (D.all.c) ))%*%(meatT.c)%*%solve(t(D.all.c))
  
  VI.c        <-  t((Ubet.c  ) ) %*% (Ubet.c * pis.c    )
  VII.c       <- t( Ubet.c * ( 1-pis.c) ) %*% (Ubet.c )
  VIpi.c       <- t(Upi.c ) %*%(Upi.c ) 
  Cbetpi.c     <-  t( Ubet.c   )%*%Upi.c[idbet,]*(simul) 
  meatT.c     <-   rbind( cbind(VI.c+VII.c, Cbetpi.c*simul ) , cbind(t(Cbetpi.c*simul ), VIpi.c) ) 
  covT.c     <-  (solve( (D.all.cE) ))%*%(meatT.c)%*%solve(t(D.all.cE))
  
  
sdWL  <- sqrt(diag(covT))[ 1: length(beta0)]  
t.val  <- beta0/sdWL  
p.val  <- 2*(1- pnorm(t.val))

sdCL  <- sqrt(diag(covT.c))[ 1: length(beta0)]  
t.val.c  <- beta0.c/sdCL
p.val.c  <- 2*(1- pnorm(t.val.c))


  
coeffWL   <- cbind(beta0, sdWL, t.val,p.val )
coeffCL   <- cbind(beta0.c, sdCL, t.val.c,p.val.c )

colnames(coeffWL) <- c('Coeff','se','t.val', 'p.val')
colnames(coeffCL) <- c('Coeff','se','t.val', 'p.val') 

rownames(coeffWL) <-   rownames(coeffCL)  <- colnames(Za)
  
  return(  list (  coeffWL=coeffWL, coeffCL=coeffCL, alp=alp0,   alp.c=alp0.c,   eps=eps,  covT=covT , covT.c=covT.c) )
  
}




