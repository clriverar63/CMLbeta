 
SW <- function(Ya,R, pi0a,bet,  Za, dist='gaussian', link='identity', ids = 1:length(R) ){ 
 
Za        <- cbind(Za)
names(Ya) <- names(R) <- names(pi0a) <-   rownames(Za) <- ids ;
id.sam   <-ids[R==1] 
Z   <- cbind(Za[R==1, ])
Y   <- Ya[R==1 ]    
pi0 <- pi0a[R==1]
W     <- diag(1/pi0)
w     <- 1/pi0

 
OneV  <- rep(1, length(pi0))
n     <- length(w)

  


if( dist=='gaussian'){  
		if(link=='identity'){   
 
	 
		                 MU   <- as.vector(Z%*%bet  )
		                 Vi    <- Y - MU
							       D    <- Z
							       I    <- t(Z)%*%(Z  )
							       Iw   <- t(Z)%*%(Z* w )
							       dUw <- -t(D)%*%(w*D) 
							       
					 
							   
			}
		
		if(link=='log'){          
		              MU   <-  as.vector( exp(Z%*%bet) )
		              Vi    <- Y - MU
								  D    <-  MU*Z
								  I    <-  t(Z)%*%(Z*MU )
								  Iw   <-  t(Z)%*%(Z*MU*w )
								  dUw <-   t(D)%*%(w*as.vector(Y-MU)*Z) -  t(D)%*%(w*D)
			}
		
		if(link=='inverse'){      
		              MU   <-  as.vector( 1/(Z%*%bet) ) 
		              Vi    <- Y - MU
								  D    <-  -MU^2*Z
								  I    <-  2*t(Z)%*% (Z*MU^3 )
								  Iw   <-  2*t(Z)%*% (Z*w*MU^3 )
								  dUw  <-   -2*t(D)%*%(MU*w*as.vector(Y-MU)*Z) -  t(D)%*%(w*D)
			}
			
	
 	Vi    <- Y - MU
 	 
	Uwi   <- D*(as.vector(Y-MU) ) 
	Sw    <- colSums(Uwi*w) 
	
 	
        }


if( dist=='binomial'){  
		if(link=='identity' || link=='logit' ){ 
		 
		                    MU <-  as.vector( 1/(1+exp(-Z%*%bet) ) )
		                    Vi     <-  (1 -MU)*(MU )
												D  <- MU*(1-MU)*Z
												I  <- t(Z)%*%  (Z*((1-2*MU)*(1-MU)*MU))
												Iw  <- t(Z)%*%  ( w*(1-2*MU)*D)
										#		dUw  <- t(D)%*%( (1-2*MU)*((Y - MU)/(MU*(1-MU)))* Z) + t(D)%*%(( -1/(MU*(1-MU))- ((Y - MU)*(1-2*MU))/((MU*(1-MU))^2) )*D )
												dUw  <- -t(D)%*%( w*Z  )
												Uaux <-  (Y-MU)/((1-MU)*MU)
												Iwaux  <- t(Z)%*%  ( w*(1-2*MU)*D* Uaux)
												dUw  <- -t(D)%*%( w*D*( Uaux^2    )) + Iwaux
												
			}
		
		if(link=='log'){                        
		                    MU   <-  as.vector( exp( Z%*%bet ) )
		                    Vi     <-  (1 -MU)*(MU )
												D    <-  MU*Z	
												I    <-  t(Z)%*% (Z*MU) 
												Iw   <-  t(Z)%*% (Z*MU*w) 
											
												dUw  <-  t(D)%*%(w*as.vector(Y-MU)*Z/((1-MU)^2)) -  t(D)%*%(w*D/Vi)
												dUw  <-  t(D)%*%(w*as.vector(Y-MU)*Z/((1-MU)^2)  -     w*Z/(1-MU))
											
												
												
									#			-t(D)%*%( w*D/(Vi    )) + t((Y-MU)*w*(D ))%*%(Z/Vi)  - t(   (D*w  - 2*MU*D*w)/(Vi^2)   )%*%((Y-MU)*D)
												
												
												
													Uaux <-  (Y-MU)/((1-MU)*MU)
												Iwaux  <- t(Z)%*% (Z*MU*w*Uaux) 
												dUw  <- -t(D)%*%( w*D*( Uaux^2    )) + Iwaux
												dUw  <-  t(D)%*%(w*as.vector(Y-MU)*Z/((1-MU)^2)  -     w*Z/(1-MU))
												
												
												
											
												
												
			}
		
		if(link=='probit'){   Nu <- as.vector(Z%*%bet)                   
		                      MU <-  pnorm(Nu) 
		                      Vi     <-  (1 -MU)*(MU )
											    D  <- dnorm(Nu)*Z	
											    I  <-  t(Z)%*% (   -Nu*dnorm(Nu)  *Z)
											    Iw  <- t(Z)%*% ( -Nu* dnorm(Nu)  *Z*w)
											    dUw  <- t(Z)%*%( ( as.vector(  Z%*%bet)  * as.vector( dnorm((Z%*%bet) )) )*( ((Y - MU)/(MU*(1-MU)))* MU) * Z) + t(D)%*%(( -1/(MU*(1-MU))- ((Y - MU)*(1-2*MU))/((MU*(1-MU))^2) )*D )
											    Uaux <-  (Y-MU)/((1-MU)*MU)
											    Iwaux  <- t(Z)%*% ( -Nu* dnorm(Nu)  *Z*w* Uaux)
											    dUw  <- -t(D)%*%( w*D*( Uaux^2    )) + Iwaux
											   
											    
			}
	
	Vi     <-  (1 -MU)*(MU )
	Uwi    <-  D*(as.vector(Y-MU)/Vi)  

	Sw     <-  colSums(Uwi*w) 
	 
	
	
	
        }
        
if( dist=='poisson'){  
  
		if(link=='identity' || link=='log' ){   
		                      MU <-  as.vector(exp(Z%*%bet)  )
		                      Vi    <- (MU ) 
											    D  <- MU*Z		
											    I  <- t(Z)%*%  (Z* MU^2) 
											    Iw  <- t(Z)%*%  (Z*w* MU^2) 
											    #dUw  <- t(D)%*%(w*as.vector(Y-MU)*Z/Vi) +  t(D)%*%(-w*D/Vi-(w*as.vector(Y-MU)*D/(Vi^2)))		
											    dUw  <- -t(D)%*%(w*Z)		
		}
		
		if(link=='sqrt'){     
		                      MU <-   as.vector(( Z%*%bet )^2)
		                      Vi    <- (MU ) 
											    D  <- 2*sqrt(MU)*Z	
											    I  <- t(Z)%*% ( Z	/sqrt(MU)) 
											    Iw  <- t(Z)%*% ( Z*w	/sqrt(MU)) 
											    #dUw  <- t(D)%*%((MU^(1/2))*w*as.vector(Y-MU)*Z/Vi) +  t(D)%*%(-w*D/Vi-(w*as.vector(Y-MU)*D/(2*Vi^2)))				  
											    dUw  <- -t(D)%*%( w*D/Vi) +  t(D)%*%(-w*(Y-MU)*Z/(MU^(3/2)))	
											    dUw  <- -t(D*( w*(Y+MU)/(2*MU^2)))%*%D
											    
											    
											    
											    
											    
			}
	
  Vi    <- (MU ) 
	Uwi   <- D*(as.vector(Y-MU)/Vi)  
	Sw    <- colSums(Uwi*w) 
	
        }        

if( dist=='exponential'){  
		if(link=='identity' || link=='inverse'){ 
		                       MU <-   as.vector(-1/( Z%*%bet )) 
		                       Vi    <- (MU^2 ) 
											     D  <-   MU^2 *Z		
											     I  <-   t(Z)%*% ((-2*MU^3)*Z )
											     Iw  <-  t(Z)%*% ((-2*MU^3)*Z*w )
											     dUw <-  2*t(D)%*%(  (w*(as.vector(Y-MU)*MU/Vi)*Z )  )+t(D)%*%( ( -w/Vi - 2*w*(Y-MU)*MU/(Vi^2))* D )
			}
		
		if(link=='log'){       
		                       MU <-  as.vector( exp( Z%*%bet ))
		                       Vi    <- (MU^2 ) 
											     D  <-   MU *Z	
											     I  <-   t(Z)%*% ( Z*MU ) 
											     Iw  <-   t(Z)%*% ( Z*MU*w ) 
											     dUw <-    t(D)%*%(  (w*(as.vector(Y-MU)/Vi) )*Z ) +t(D)%*%( ( -w/Vi - 2*w*(Y-MU)*MU/(Vi^2) )*D )
											     
											      
											     
		}
  
  
	
	Vi    <- (MU^2 ) 
	Uwi   <- D*(as.vector(Y-MU)/Vi)  
	Sw    <- colSums(Uwi*w) 
	
     
     
        } 

if( dist=='Gamma'){  
		if(link=='identity' || link=='inverse'){ 
		                     MU <- as.vector(-1/( Z%*%bet )) 
		                     Vi    <- (MU^2 ) 
												 D  <- MU^2 *Z	
												 I   <- t(Z)%*% ((-2*MU^3)*Z) 	
												 Iw  <- t(Z)%*% ((-2*MU^3)*Z*w) 
											     dUw <-  2*t(D)%*%(  (w*(as.vector(Y-MU)*MU/Vi)*Z )  )+t(D)%*%( ( -w/Vi - 2*w*(Y-MU)*MU/(Vi^2))* D )
											     dUw <- -t(D*w)%*%Z
												 
			}
		
		if(link=='inverse2'){                   
		                       MU <-  as.vector(1/( Z%*%bet ))
		                       Vi    <- (MU^2 ) 
											     D  <- -MU^2 *Z	 	
											     I  <- -t(Z)%*% ((-2*MU^3)*Z) 	
											     Iw  <- -t(Z)%*% ((-2*MU^3)*Z*w) 
											     dUw <-  -(2*t(D)%*%(  (w*(as.vector(Y-MU)*MU/Vi)*Z )  )+t(D)%*%( ( -w/Vi - 2*w*(Y-MU)*MU/(Vi^2))* D ))
											     dUw <- t(D*w)%*%Z
			}
		
		if(link=='log'){      
		                       MU <- as.vector(exp(Z%*%bet)  )
		                       Vi    <- (MU^2 ) 
											     D  <- MU*Z		
											     I  <- t(Z)%*% ( MU*Z ) 
											     Iw  <- t(Z)%*% ( MU*Z*w )  
											     dUw <-    t(D)%*%(  (w*(as.vector(Y-MU)/Vi) )*Z ) +t(D)%*%( ( -w/Vi - 2*w*(Y-MU)*MU/(Vi^2) )*D )
											     dUw <- t(D*w*(-Y/(MU^2)))%*%Z
			}  
 

	Uwi   <- D*(as.vector(Y-MU)/Vi)  
	Sw    <- colSums(Uwi*w) 
}
	#dUwi   <- t(D)%*%(D*(as.vector(Y-MU)/Vi)) 


	return(list(	Uwi=	Uwi, 	 w=	 w  , Sw=Sw,  ids= ids, id.sam=id.sam , D=D, Iw= Iw, dUw=dUw, MU=MU))
} 
 
        